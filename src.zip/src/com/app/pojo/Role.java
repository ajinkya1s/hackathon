package com.app.pojo;

public enum Role {
	USER,LIBRARIAN,OWNNER
}
