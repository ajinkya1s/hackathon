package com.app.pojo;

import java.util.Date;

public class Payments 
{
	private Integer id;
	private Integer userId;
	private Double amount;
	private Ptype type;
	private Date transaction_time;
	private Date nextpayment_duedate;
	
	public Payments() {
		// TODO Auto-generated constructor stub
	}

	public Payments(Integer id, Integer userId, Double amount, Ptype type, Date transaction_time,
			Date nextpayment_duedate) {
		super();
		this.id = id;
		this.userId = userId;
		this.amount = amount;
		this.type = type;
		this.transaction_time = transaction_time;
		this.nextpayment_duedate = nextpayment_duedate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Ptype getType() {
		return type;
	}

	public void setType(Ptype type) {
		this.type = type;
	}

	public Date getTransaction_time() {
		return transaction_time;
	}

	public void setTransaction_time(Date transaction_time) {
		this.transaction_time = transaction_time;
	}

	public Date getNextpayment_duedate() {
		return nextpayment_duedate;
	}

	public void setNextpayment_duedate(Date nextpayment_duedate) {
		this.nextpayment_duedate = nextpayment_duedate;
	}

	@Override
	public String toString() {
		return "Payments [id=" + id + ", userId=" + userId + ", amount=" + amount + ", type=" + type
				+ ", transaction_time=" + transaction_time + ", nextpayment_duedate=" + nextpayment_duedate + "]";
	}
	
}
