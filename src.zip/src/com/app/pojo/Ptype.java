package com.app.pojo;

public enum Ptype {
	CREDITCARD,DEBITCARD,CASH

}
